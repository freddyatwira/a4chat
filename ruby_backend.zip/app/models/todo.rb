class Todo < ApplicationRecord
	has_one_attached :image
end
